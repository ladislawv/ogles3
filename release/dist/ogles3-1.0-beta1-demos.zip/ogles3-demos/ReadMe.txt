Boing 2026, Boing Ocean, Boing Swarm and Juggler RT for OpenGL ES 3 (ogles3.library 1.0-beta1)
================================================================================================

Four demos of ogles3.library, OpenGL ES 3.1 for AmigaOS 3.x on PiStorm with a
Raspberry Pi 4 (Emu68, a 32-bit RTG screen).

  boing2026-ogles3     the 1984 Boing Ball dives into a pool: waves,
                       caustics and the light they throw on the walls
                       worked out on the GPU. Keys and options:
                       boing2026-ogles3.txt
  boingocean-ogles3    the Boing Ball on an ocean in high dynamic range,
                       with clouds and sun glints. Keys and options:
                       boingocean-ogles3.txt
  boingswarm-ogles3    16384 lights simulated by the GPU flock into a
                       spinning Boing Ball, burst, and fly as a
                       murmuration. Keys and options: boingswarm-ogles3.txt
  juggler-ogles3       Eric Graham's 1987 Juggler, ray traced in real
                       time by compute shaders: in 1987's 320 x 200 HAM,
                       or 2026's full size with soft shadows. Keys and
                       options: juggler-ogles3.txt

Unpack anywhere and double-click, or start from a Shell (FULLSCREEN for a
1280 x 720 screen). Nothing needs installing: each finds ogles3.library in
libs/ beside it, and its compiled shaders in shaders/. Esc quits; E switches
to the OpenGL ES 2.0 way of drawing the same scene, to compare.

The full release (installer, shader compiler, SDK, more examples):
https://github.com/ladislawv/ogles3

Licences: ogles3.library is under the Hyperion MiniGL Open Source License
(licences/License_MiniGL_Library.txt); the demos are MIT (LICENSE).
